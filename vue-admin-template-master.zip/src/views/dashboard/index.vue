<template>
  <div class="dashboard-container">
    <div class="dashboard-text">name: {{ user.username }}</div>
    <div class="dashboard-info">borrownow: {{ user.borrownow }}</div>
    <div class="dashboard-info">borrowtimes: {{ user.borrowtimes }}</div>
    <div class="dashboard-info">createtime: {{ user.createtime }}</div>
  </div>
</template>

<script>
  //import { mapGetters } from 'vuex'
  import {
    getToken,
    getUser
  } from '@/utils/auth'
  import {
    parseTime
  } from '@/utils'

  export default {
    name: 'Dashboard',
    computed: {
      // ...mapGetters([
      //   'name'
      // ])
      user: function() {
        const user = getUser()
        user.createtime = parseTime(user.createtime)
        return user
      }
    }
  }
</script>

<style lang="scss" scoped>
  .dashboard {
    &-container {
      margin: 30px;
    }

    &-text {
      font-size: 30px;
      line-height: 46px;
    }

    &-info {
      font-size: 20px;
      line-height: 46px;
    }
  }
</style>
