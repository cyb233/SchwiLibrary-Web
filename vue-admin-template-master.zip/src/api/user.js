import request from '@/utils/request'

export function login(data) {
  return request({
    url: 'http://localhost:8888/user/login',
    method: 'post',
    data
  })
}

export function register(data) {
  return request({
    url: 'http://localhost:8888/user/register',
    method: 'post',
    data
  })
}

export function searchUser(data) {
  return request({
    url: 'http://localhost:8888/user/query',
    method: 'post',
    data
  })
}

export function logout() {
  return request({
    url: '/vue-admin-template/user/logout',
    method: 'post'
  })
}
